$(document).ready(function(){
  var backlog = [];
  var svg_file = $("#drawing").attr("src");
  var console = $('#console').console({
    promptLabel: '=> ',
    commandValidate:function(line){
      if (line == '') return false;
      else return true;
    },
    commandHandle:function(line, report){
      $.ajax({
        type: 'POST',
        url: '/eval',
        data: JSON.stringify({code: line, env: backlog}),
        contentType: 'application/json',
        dataType: 'json',
        success: function(data) {
          $("#drawing").attr("src", svg_file + "?" + new Date().getTime());
          report([{msg : data.stdout, className:'jquery-console-message-value'},
                  {msg : data.stderr, className:'jquery-console-message-error'}]);
        }
      });
      backlog.push(line);
    },
    animateScroll:true,
    promptHistory:true,
    autofocus:true,
    welcomeMessage: 'y-turte'
  });
  console.promptText('(repeat 3 (repeat 6 (move 40) (turn 60) (repeat 6 (move 10) (turn 60))) (turn 120))');
});


if (!String.prototype.supplant) {
    String.prototype.supplant = function (o) {
        return this.replace(
            /\{([^{}]*)\}/g,
            function (a, b) {
                var r = o[b];
                return typeof r === 'string' || typeof r === 'number' ? r : a;
            }
        );
    };
}
