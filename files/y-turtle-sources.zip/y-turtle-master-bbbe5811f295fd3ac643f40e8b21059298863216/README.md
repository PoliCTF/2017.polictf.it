# Escape from the y-turtle

## Description
A new cyber-artistic collective had fun experimenting with metaprogramming and
domain specific languages. Here thre is a first, broken, implementation of a
Turtle graphic engine.

## Deploy
- `mkdir svg` (svg must be writable)
- `python -m pip install -r requrements.txt --user`
- `python main.py` (runs on port 5000)

## Exploit
`./exploit.py`
