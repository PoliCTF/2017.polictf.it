from hy.importer import import_file_to_module
__hymain__ = import_file_to_module('__hymain__', 'main.hy')

app = __hymain__.app

if __name__ == '__main__':
    app.run()
