#!/usr/bin/python
#-*- coding: utf-8 -*-

import socket

def get_ip(environ):
    """
    Return the IP address of the client (based on REMOTE_ADDR of HTTP_X_FORWARDED_FOR if available)
    """
    return environ["HTTP_X_FORWARDED_FOR"] if "HTTP_X_FORWARDED_FOR" in environ.keys() else environ["REMOTE_ADDR"]


def validate_ip(ip):
    """
    Validate that the given IP address is a valid one: decoded to avoid problem in sqlite
    """
    socket.inet_aton(ip)
    return ip.decode("utf-8", "ignore")