#!/usr/bin/python
#-*- coding: utf-8 -*-

from os import urandom
import sqlite3, cgi, socket, Cookie, hashlib, hmac, pickle, cuoco
from cuoco import *
from pyzzamargherita import *
from pyzzastuffed import *


def wsgi_app(environ, start_response):
    status = '200 OK'
    headers = [('Content-type', 'text/html;charset=utf-8')]
               
    start_response(status, headers)
    yield open("/srv/http/pyzzeria/templates/header.tpl", "r").read()



    if 'HTTP_COOKIE' in environ:
        #yield "parsing cookies<br>"
        cookies = Cookie.SimpleCookie(environ['HTTP_COOKIE'])
        if 'pyzza' in cookies:
            if environ['REQUEST_METHOD'] != 'POST':
                yield open("/srv/http/pyzzeria/templates/oven_form.tpl").read()
                yield open("/srv/http/pyzzeria/templates/footer.tpl","r").read()
                return
                
            
            c = Cuoco("Gennaro", "Esposito", 1337)

            try:
                pyzza_t, pyzza, signature = cookies['pyzza'].value.decode("hex").split(":")
                #yield signature + "<br>"
                
                if signature != hmac.new(c.get_secret(), pyzza.decode("base64"), hashlib.sha256).hexdigest():
                    yield "verify_hmac_signature() failure: Tampering attempt detected! Your request has been <a href='/warehouse/logs/tampering_attempts'>logged</a>.<br>"
                    yield open("/srv/http/pyzzeria/templates/footer.tpl","r").read()
                    return
                p = pickle.loads(pyzza.decode("base64"))
                #yield str(p.age) + "<br>"
                c.cook(p, int(pyzza_t.encode("hex"),16))
            except Exception as e:
                yield str(e)
                yield open("/srv/http/pyzzeria/templates/footer.tpl","r").read()
                return
            
            try:
                content_len = int(environ.get('CONTENT_LENGTH', 0)) if int(environ.get('CONTENT_LENGTH', 0)) > 0  else 0
            except (ValueError):
                content_len = 0
            
            try:
                req_body = cgi.parse_qs(environ['wsgi.input'].read(content_len))
                order_code = req_body.get("order_code")[0]
                #yield "order: {0}, type: {1}<br>".format(p.order_code, type(p.order_code))
                #yield "given: {0}, type: {1}<br>".format(order_code, type(order_code))
            except:
                yield "Invalid order code"
                yield open("/srv/http/pyzzeria/templates/footer.tpl","r").read()
                return
            
            last =  c.get_last_order()
            last_order = last.split("\n")
            #yield str(last_order) + "<br>"
            if "leavening" in last_order[0]:
                yield "[+] You ordered a " + last_order[0].split("leavening: ")[1] + " hour leaven Margherita [+]<br>"
            yield "[+] Checking your order code [+]<br>"
            #yield "last: {}<br><br>".format(last_order[1].split("order: ")[1])
            #yield "============<br>" + last + "<br>" + "============<br>"
            
            if order_code != last_order[1].split("order: ")[1]:
                yield "[X] Sorry, order verification failed. [X]"
                yield open("/srv/http/pyzzeria/templates/footer.tpl","r").read()
                return
            
            yield "[+] Your pyzza (with extra pineapple :D) is ready, here is your recipt [+]<br><br>"
            yield "============<br>" + last.replace("\n","<br>") + "<br>" + "============<br>"
            yield open("/srv/http/pyzzeria/templates/footer.tpl","r").read()
            return

        yield "Sorry, no orders for you."
        yield open("/srv/http/pyzzeria/templates/footer.tpl","r").read()

            #yield pyzza_t
            #yield pyzza

application = wsgi_app
