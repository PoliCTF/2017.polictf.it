#!/usr/bin/python
#-*- coding: utf-8 -*-

import sys

sys.path.append("/srv/http/pyzzeria")

from os import urandom
import cgitb, cgi, socket, Cookie, hashlib, hmac, pickle
import sqlite3
from ip import *
from cuoco import *
from pyzzamargherita import *
from pyzzastuffed import *

cgitb.enable()

database = sqlite3.connect("/srv/http/pyzzeria/db/allowed.db", check_same_thread=False)
c = database.cursor()

def check_bruteforce(ip):
    c.execute("SELECT n,ts,strftime('%s','now') FROM attempts WHERE ip = ?", [ip])
    row = c.fetchone()

    if row != None:
        attempts = int(row[0])
        ts = int(row[1])
        now = int(row[2])

        if attempts >= 5:
            if now-ts >= 10:
                c.execute("UPDATE attempts SET n=0,ts=0 WHERE ip = ?", [ip])
                database.commit()
                return False
            else:
                return True
        else:
            c.execute("UPDATE attempts SET n=n+1,ts=strftime('%s','now') WHERE ip = ?", [ip])
            attempts = attempts + 1
            database.commit()
            return False
    else:
        c.execute("INSERT INTO attempts VALUES(?, 1, strftime('%s','now'))", [ip])
        database.commit()
        return False
    

def is_ip_allowed(ip):
    try:
        c.execute("SELECT * FROM allowed WHERE ip = '" + ip + "'")
        return (False, "The access is currently restricted to staff only ¯\_(ツ)_/¯") if c.fetchone() == None else (True, "")
    except Exception as e:
        return (False, str(e))

def is_logged_in(session):
    try:
        c.execute("SELECT * FROM logged WHERE session = ?", [session])
        return (c.fetchone() != None)
    except Exception as e:
        return False

def get_session(environ):
    if 'HTTP_COOKIE' not in environ:
        return None
    cookies = Cookie.SimpleCookie(environ['HTTP_COOKIE'])
    return cookies["pySessId"].value if ('pySessId' in cookies) else None
           

def login(session):
    try:
        c.execute("SELECT * FROM logged WHERE session = ?", [session])
        if c.fetchone() == None:
            c.execute("INSERT INTO logged VALUES(?)", [session])
            database.commit()
    except Exception as e:
        exit()

def fuck(session):
	c.execute("DELETE FROM logged WHERE session = ?", [session])
	database.commit()

def wsgi_app(environ, start_response):
    """
    Real WSGI application
    """
    status = '200 OK'
    headers = [('Content-type', 'text/html;charset=utf-8')]
    allowed = False

    session =  get_session(environ) 
    if session != None:
        if is_logged_in(session):
            allowed = True
            #yield "Logged in\n"
    else:
        session = urandom(32).encode("hex")
        headers.append(('Set-Cookie', 'pySessId=' + session))


    body = open("/srv/http/pyzzeria/templates/header.tpl", "r").read()
    
    if allowed == False:

        try:    
            ip = validate_ip(get_ip(environ))
        except Exception as e:
            start_response(status, headers)
            body += "validate_ip() failure: " + str(e)
            body += open("/srv/http/pyzzeria/templates/footer.tpl","r").read()
            yield body
            return


        if check_bruteforce(ip):
            start_response(status, headers)
            body += "You already tried too many times"
            body += open("/srv/http/pyzzeria/templates/footer.tpl","r").read()
            yield body
            return


        allowed_ip = is_ip_allowed(ip)
        if not allowed_ip[0]:
            start_response(status, headers)
            body += allowed_ip[1]
            body += open("/srv/http/pyzzeria/templates/footer.tpl","r").read()
            yield body
            return

        login(session)  

    if environ['REQUEST_METHOD'] == 'GET':
        body += open("/srv/http/pyzzeria/templates/form.tpl", "r").read()
        body += open("/srv/http/pyzzeria/templates/footer.tpl","r").read()
        start_response(status, headers)
        yield body
        return


    if environ['REQUEST_METHOD'] == 'POST':
        try:
            content_len = int(environ.get('CONTENT_LENGTH', 0)) if int(environ.get('CONTENT_LENGTH', 0)) > 0  else 0
        except (ValueError):
            content_len = 0

        req_body = cgi.parse_qs(environ['wsgi.input'].read(content_len))
        
        try:
            pyzza_type = req_body.get("type")[0]
            if pyzza_type == 'S':
                pyzza_stuff = ','.join(req_body.get("ingredients"))[:150]
                if "pineapple" in pyzza_stuff.lower():
                	fuck(session)
			start_response(status, headers)
			body += "Pinefuckingapple doesn't go on a pizza. Ever."
			yield body
			return
                #body += "ingredients: " + pyzza_stuff + "\n"
                my_pyzza = PyzzaStuffed(urandom(16).encode("hex"), pyzza_stuff)
            elif pyzza_type == 'M':
                leavening = long(req_body.get("leavening")[0])
                #body += "age: " + str(leavening) + "\n" 
                my_pyzza = PyzzaMargherita(urandom(16).encode('hex'), leavening)
            else:
                raise ValueError
        except Exception as e:
		body += open("/srv/http/pyzzeria/templates/exception.tpl","r").read()
                body += open("/srv/http/pyzzeria/templates/footer.tpl","r").read()
                start_response(status, headers)
                #yield str(e)
                yield body
                return


        c = Cuoco("Gennaro", "Esposito", 1337)
        my_pickled_pyzza = pickle.dumps(my_pyzza)
        signature = hmac.new(c.get_secret(), my_pickled_pyzza, hashlib.sha256).hexdigest()
        pyzza = (my_pickled_pyzza).encode('base64').replace('\n', '')
        #body += "Here is your Pyzza: {}\nHere is your signature: {}".format(pyzza, signature)  
        body += "Got your order, your Pyzza is on its way to the <a href='/oven'>oven</a>!<br>Your order code is " + my_pyzza.order_code
        headers.append(('Set-Cookie', 'pyzza='+(pyzza_type+':'+pyzza+':'+signature).encode("hex")))

    body += open("/srv/http/pyzzeria/templates/footer.tpl","r").read()
    start_response(status, headers)
    yield body 


application = wsgi_app

