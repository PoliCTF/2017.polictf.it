#include <Python.h>
#include "structmember.h"
#include "PyzzaError.h"

PyMODINIT_FUNC initpyzzaerror(void) {
    PyObject* m;

    if (PyType_Ready(&PyzzaErrorType) < 0)
        return;

    m = Py_InitModule3("pyzzaerror", module_methods,
                       "Basic template for pyzzaerror object");

    if (m == NULL)
        return;

    Py_INCREF(&PyzzaErrorType);
    PyModule_AddObject(m, "PyzzaError", (PyObject *)&PyzzaErrorType);
}

static PyObject *PyzzaError_new(PyTypeObject *type, PyObject *args, PyObject *kwds) {
	PyzzaError *self;

	self = (PyzzaError *)type->tp_alloc(type, 0);
	if (self != NULL) {
        
		self->msg = "";
		if (self->msg == NULL) {
			Py_DECREF(self);
			return NULL;
		}
		
		self->hdr = "";
		if (self->hdr == NULL) {
			Py_DECREF(self);
			return NULL;
		}

	}

	return (PyObject *)self;
}

static int PyzzaError_init(PyzzaError *self, PyObject *args, PyObject *kwds) {
    char *msg = NULL;
    char *hdr = NULL;
    PyObject *tmp = NULL;

    static char *kwlist[] = {"hdr", "msg", NULL};

    if (!PyArg_ParseTupleAndKeywords(args, kwds, "ss", kwlist, &msg, &hdr))
        return -1;

    if (msg) {
        //tmp = self->msg;
        //Py_INCREF(msg);
        self->msg = strdup(msg);
        //Py_XDECREF(tmp);
    }

    if (hdr) {
        self->hdr = strdup(hdr);
    }

    return 0;
}

static void PyzzaError_dealloc(PyzzaError *self) {
	//Py_XDECREF(self->msg);
	Py_TYPE(self)->tp_free((PyObject*)self);
}

static PyObject *PyzzaError_serialize(PyzzaError* self) {
    return Py_BuildValue("O(ss)", Py_TYPE(self), self->msg, self->hdr);
}



