#include <Python.h>
#include "structmember.h"

static char *secret="y3y0y3y0y3y0y3!";
static char *invalid="INVALID!";

typedef struct {
	PyObject_HEAD
	PyObject *name; 
	PyObject *surname;
	int age;
	PyObject *last_order;
} Cuoco;

typedef struct {
	PyObject_HEAD
	unsigned long age;
	char *order_code;
	int price;
} PyzzaMargherita;

typedef struct {
	PyObject_HEAD
	char *order_code;
	char *ingredients;
	int price;
} PyzzaStuffed;

typedef struct {
    PyObject_HEAD
    char *hdr;
	 char *msg;
	 int price;
} PyzzaError;

static void Cuoco_dealloc(Cuoco* self) {
	Py_XDECREF(self->name);
	Py_XDECREF(self->surname);
	Py_XDECREF(self->last_order);
	Py_TYPE(self)->tp_free((PyObject*)self);
}

static PyObject *Cuoco_new(PyTypeObject *type, PyObject *args, PyObject *kwds) {
    Cuoco *self;

    self = (Cuoco *)type->tp_alloc(type, 0);
    if (self != NULL) {
		
		self->last_order = PyString_FromString("");
		if (self->last_order == NULL) {
			Py_DECREF(self);
			return NULL;
		}
		
		self->name = PyString_FromString("");
      if (self->name == NULL) {
          Py_DECREF(self);
          return NULL;
      }

      self->surname = PyString_FromString("");
      if (self->surname == NULL) {
          Py_DECREF(self);
          return NULL;
      }
      self->age = 0;
  }

  return (PyObject *)self;
}

static int Cuoco_init(Cuoco *self, PyObject *args, PyObject *kwds) {
    PyObject *name = NULL;
    PyObject *surname = NULL;
    PyObject *tmp;

    static char *kwlist[] = {"name", "surname", "age", NULL};

    if (! PyArg_ParseTupleAndKeywords(args, kwds, "OO|i", kwlist, &name, &surname, &self->age))
        return -1;

    if (name) {
        tmp = self->name;
        Py_INCREF(name);
        self->name = name;
        Py_XDECREF(tmp);
    }

	if (surname) {
        tmp = self->surname;
        Py_INCREF(surname);
        self->surname = surname;
        Py_XDECREF(tmp);
    }

    return 0;
}

PyObject *cook_margherita(PyzzaMargherita *p){
	static PyObject *fmt = NULL;
	PyObject *args, *result;
	//fmt = PyString_FromString("leavening: %d\nleak: %d\norder: %s\n");
	fmt = PyString_FromString("leavening: %lu\norder: %s\nprice: %d€");
	//args = Py_BuildValue("lls", p->age, secret, p->order_code);
	args = Py_BuildValue("lsi", p->age, p->order_code, p->price);
	result = PyString_Format(fmt, args);
	Py_DECREF(args);

	return result;
}

PyObject *cook_stuffed(PyzzaStuffed *p){
	static PyObject *fmt = NULL;
	PyObject *args, *result;
	
	fmt = PyString_FromString("ingredients: %s\norder: %s\nprice: %d€");
	args = Py_BuildValue("ssi", p->ingredients, p->order_code, p->price);
	result = PyString_Format(fmt, args);
	Py_DECREF(args);

	return result;
}

static char *Cuoco_get_last_order(Cuoco *self, PyObject *args) {
	return Py_BuildValue("s", PyString_AsString(self->last_order));
}

static int Cuoco_cook(Cuoco *self, PyObject *args, PyObject *kwds) {
	int type;
	PyObject *pyzza;
	PyObject *result;


	static char *kwlist[] = {"pyzza", "type", NULL};

	if (! PyArg_ParseTupleAndKeywords(args, kwds, "Oi", kwlist, &pyzza, &type)){
		PyErr_SetString(PyExc_ValueError, "Invalid arguments.");
		return NULL;
	}

	if (pyzza) {
		printf("Pyzza obj @: %p\n", pyzza);
	}
	if (type) {
		printf("Pyzza type %d\n", type);
	}

	if(type != 'M' && type != 'S'){
		PyzzaError *perr = (PyzzaError *) malloc(sizeof(PyzzaError));
		perr->hdr = invalid;
		perr->msg = "invalid test";
		pyzza = perr;
	}

//	printf("leak: %p\n", secret);

	switch( (char) type) {
		case 'M':
			self->last_order = cook_margherita(pyzza);
			break;
		case 'S':
			self->last_order = cook_stuffed(pyzza);
			break;
		default:
			PyErr_SetString(PyExc_ValueError, "Invalid pyzza type.");
			return NULL;
	 }
			
	return Py_BuildValue("i", 1);
}

static char *Cuoco_get_secret(Cuoco *self, PyObject *args) {
	return Py_BuildValue("s", secret);
}

static PyMemberDef Cuoco_members[] = {
	{"name", T_OBJECT_EX, offsetof(Cuoco, name), 0, "name"},
	{"surname", T_OBJECT_EX, offsetof(Cuoco, surname), 0, "surname"},
	{"age", T_INT, offsetof(Cuoco, age), 0, "age"},
	{"last_order", T_OBJECT_EX, offsetof(Cuoco, last_order), 0, "last_order"},
	{NULL}  
};


static PyMethodDef Cuoco_methods[] = {
    {"cook", (PyCFunction)Cuoco_cook, METH_VARARGS, "Cook the order with ID id and TYPE type"},
    {"get_last_order", (PyCFunction)Cuoco_get_last_order, METH_NOARGS, "Return the last cooked pyzza's order"},
    {"get_secret", (PyCFunction)Cuoco_get_secret, METH_NOARGS, "Return the the secret"},
    {NULL}  /* Sentinel */
};

static PyTypeObject CuocoType = {
	PyVarObject_HEAD_INIT(NULL, 0)
	"cuoco.Cuoco",             /* tp_name */
	sizeof(Cuoco),             /* tp_basicsize */
	0,                         /* tp_itemsize */
	(destructor)Cuoco_dealloc, /* tp_dealloc */
	0,                         /* tp_print */
	0,                         /* tp_getattr */
	0,                         /* tp_setattr */
	0,                         /* tp_compare */
	0,                         /* tp_repr */
	0,                         /* tp_as_number */
	0,                         /* tp_as_sequence */
	0,                         /* tp_as_mapping */
	0,                         /* tp_hash */
	0,                         /* tp_call */
	0,                         /* tp_str */
	0,                         /* tp_getattro */
	0,                         /* tp_setattro */
	0,                         /* tp_as_buffer */
	Py_TPFLAGS_DEFAULT |
	Py_TPFLAGS_BASETYPE,   /* tp_flags */
	"Cuoco objects",           /* tp_doc */
	0,                         /* tp_traverse */
	0,                         /* tp_clear */
	0,                         /* tp_richcompare */
	0,                         /* tp_weaklistoffset */
	0,                         /* tp_iter */
	0,                         /* tp_iternext */
	Cuoco_methods,             /* tp_methods */
	Cuoco_members,             /* tp_members */
	0,                         /* tp_getset */
	0,                         /* tp_base */
	0,                         /* tp_dict */
	0,                         /* tp_descr_get */
	0,                         /* tp_descr_set */
	0,                         /* tp_dictoffset */
	(initproc)Cuoco_init,      /* tp_init */
	0,                         /* tp_alloc */
	Cuoco_new,                 /* tp_new */
};

static PyMethodDef module_methods[] = {
	{NULL}  /* Sentinel */
};

PyMODINIT_FUNC initcuoco(void) {
	PyObject* m;

	if (PyType_Ready(&CuocoType) < 0)
		return;

	m = Py_InitModule3("cuoco", module_methods,
							"Basic template for cuoco object");

	if (m == NULL)
		return;

	Py_INCREF(&CuocoType);
	PyModule_AddObject(m, "Cuoco", (PyObject *)&CuocoType);
}
