
typedef struct {
    PyObject_HEAD
    char *hdr;
	 char *msg;
	 int price;
} PyzzaError;

static void PyzzaError_dealloc( PyzzaError *self);
static PyObject *PyzzaError_new(PyTypeObject *type, PyObject *args, PyObject *kwds);

static int PyzzaError_init(PyzzaError *self, PyObject *args, PyObject *kwds);


static PyMemberDef PyzzaError_members[] = {
    {"hdr", T_STRING, offsetof(PyzzaError, hdr), 0, "hdr"},
    {"msg", T_STRING, offsetof(PyzzaError, msg), 0, "msg"},
    {NULL}  
};

static PyObject *PyzzaError_serialize(PyzzaError* self);

static PyMethodDef PyzzaError_methods[] = {
    {"__reduce__", (PyCFunction)PyzzaError_serialize, METH_NOARGS, "Serialize"},
    {NULL}  /* Sentinel */
};

static PyTypeObject PyzzaErrorType = {
    PyVarObject_HEAD_INIT(NULL, 0)
    "pyzzaerror.PyzzaError",   /* tp_name */
    sizeof(PyzzaError),             /* tp_basicsize */
    0,                                   /* tp_itemsize */
    (destructor)PyzzaError_dealloc, /* tp_dealloc */
    0,                                   /* tp_print */
    0,                         /* tp_getattr */
    0,                         /* tp_setattr */
    0,                         /* tp_compare */
    0,                         /* tp_repr */
    0,                         /* tp_as_number */
    0,                         /* tp_as_sequence */
    0,                         /* tp_as_mapping */
    0,                         /* tp_hash */
    0,                         /* tp_call */
    0,                         /* tp_str */
    0,                         /* tp_getattro */
    0,                         /* tp_setattro */
    0,                         /* tp_as_buffer */
    Py_TPFLAGS_DEFAULT |
        Py_TPFLAGS_BASETYPE,   /* tp_flags */
    "PyzzaError objects",           /* tp_doc */
    0,                         /* tp_traverse */
    0,                         /* tp_clear */
    0,                         /* tp_richcompare */
    0,                         /* tp_weaklistoffset */
    0,                         /* tp_iter */
    0,                         /* tp_iternext */
    PyzzaError_methods,             /* tp_methods */
    PyzzaError_members,             /* tp_members */
    0,                         /* tp_getset */
    0,                         /* tp_base */
    0,                         /* tp_dict */
    0,                         /* tp_descr_get */
    0,                         /* tp_descr_set */
    0,                         /* tp_dictoffset */
    (initproc)PyzzaError_init,      /* tp_init */
    0,                         /* tp_alloc */
    PyzzaError_new,                 /* tp_new */
};

static PyMethodDef module_methods[] = {
	{NULL}  /* Sentinel */
};

void initpyzzaerror(void);

