# from distutils.core import setup, Extension

# buggy_module = Extension('cuoco',
# 	include_dirs = ["/usr/local/include"],
# 	sources = ["cuoco.c"])


from distutils.core import setup, Extension
setup(name="pyzzamargherita", version="1.0",
      ext_modules=[
         Extension("pyzzamargherita", ["PyzzaMargherita.c"]),
         ])
setup(name="pyzzastuffed", version="1.0",
      ext_modules=[
         Extension("pyzzastuffed", ["PyzzaStuffed.c"]),
         ])
setup(
 	name = 'cuoco',
 	description = 'Just a cuoco extension',
 	author = 'p0x',
 	url = 'https://truel.it',
 	ext_modules=[Extension("cuoco", ["cuoco.c"]),
            ])

