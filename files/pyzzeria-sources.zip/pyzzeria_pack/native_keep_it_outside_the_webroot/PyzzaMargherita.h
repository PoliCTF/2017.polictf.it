
typedef struct {
    PyObject_HEAD
    unsigned long age;
	 char *order_code;
	 int price;
} PyzzaMargherita;

static void PyzzaMargherita_dealloc( PyzzaMargherita *self);
static PyObject *PyzzaMargherita_new(PyTypeObject *type, PyObject *args, PyObject *kwds);

static int PyzzaMargherita_init(PyzzaMargherita *self, PyObject *args, PyObject *kwds);


static PyMemberDef PyzzaMargherita_members[] = {
    {"age", T_LONG, offsetof(PyzzaMargherita, age), 0, "age"},
    {"order_code", T_STRING, offsetof(PyzzaMargherita, order_code), 0, "order_code"},
    {"price", T_FLOAT, offsetof(PyzzaMargherita, price), 0, "price"},
    {NULL}  
};

static PyObject *PyzzaMargherita_serialize(PyzzaMargherita* self);

static PyMethodDef PyzzaMargherita_methods[] = {
    {"__reduce__", (PyCFunction)PyzzaMargherita_serialize, METH_NOARGS, "Serialize"},
    {NULL}  /* Sentinel */
};

static PyTypeObject PyzzaMargheritaType = {
    PyVarObject_HEAD_INIT(NULL, 0)
    "pyzzamargherita.PyzzaMargherita",   /* tp_name */
    sizeof(PyzzaMargherita),             /* tp_basicsize */
    0,                                   /* tp_itemsize */
    (destructor)PyzzaMargherita_dealloc, /* tp_dealloc */
    0,                                   /* tp_print */
    0,                         /* tp_getattr */
    0,                         /* tp_setattr */
    0,                         /* tp_compare */
    0,                         /* tp_repr */
    0,                         /* tp_as_number */
    0,                         /* tp_as_sequence */
    0,                         /* tp_as_mapping */
    0,                         /* tp_hash */
    0,                         /* tp_call */
    0,                         /* tp_str */
    0,                         /* tp_getattro */
    0,                         /* tp_setattro */
    0,                         /* tp_as_buffer */
    Py_TPFLAGS_DEFAULT |
        Py_TPFLAGS_BASETYPE,   /* tp_flags */
    "PyzzaMargherita objects",           /* tp_doc */
    0,                         /* tp_traverse */
    0,                         /* tp_clear */
    0,                         /* tp_richcompare */
    0,                         /* tp_weaklistoffset */
    0,                         /* tp_iter */
    0,                         /* tp_iternext */
    PyzzaMargherita_methods,             /* tp_methods */
    PyzzaMargherita_members,             /* tp_members */
    0,                         /* tp_getset */
    0,                         /* tp_base */
    0,                         /* tp_dict */
    0,                         /* tp_descr_get */
    0,                         /* tp_descr_set */
    0,                         /* tp_dictoffset */
    (initproc)PyzzaMargherita_init,      /* tp_init */
    0,                         /* tp_alloc */
    PyzzaMargherita_new,                 /* tp_new */
};

static PyMethodDef module_methods[] = {
	{NULL}  /* Sentinel */
};

void initpyzzamargherita(void);

