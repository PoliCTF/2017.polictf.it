#include <Python.h>
#include "structmember.h"
#include "pyzzastuffed.h"

PyMODINIT_FUNC initpyzzastuffed(void) {
    PyObject* m;

    if (PyType_Ready(&PyzzaStuffedType) < 0)
        return;

    m = Py_InitModule3("pyzzastuffed", module_methods,
                       "Basic template for pyzzastuffed object");

    if (m == NULL)
        return;

    Py_INCREF(&PyzzaStuffedType);
    PyModule_AddObject(m, "PyzzaStuffed", (PyObject *)&PyzzaStuffedType);
}


static PyObject *PyzzaStuffed_new(PyTypeObject *type, PyObject *args, PyObject *kwds) {
PyzzaStuffed *self;

	self = (PyzzaStuffed *)type->tp_alloc(type, 0);

	if (self != NULL) {
		self->order_code = "";
		if (self->order_code == NULL) {
				Py_DECREF(self);
				return NULL;
		}
		self->ingredients = "";
		if (self->ingredients == NULL) {
			Py_DECREF(self);
			return NULL;
		}

		self->price = 7;
	}
	return (PyObject *)self;
}


static int PyzzaStuffed_init(PyzzaStuffed *self, PyObject *args, PyObject *kwds) {
    char *order_code = NULL;
    char *ingredients = NULL;
	 char *pineapple = NULL;
    PyObject *tmp = NULL;

    static char *kwlist[] = {"order_code", "ingredients", "pineapple", NULL};

    if (!PyArg_ParseTupleAndKeywords(args, kwds, "ss|s", kwlist, &order_code, &ingredients, pineapple))
        return -1;

    if (order_code) {
        //tmp = self->order_code;
        //Py_INCREF(order_code);
        self->order_code = strdup(order_code);
        //Py_XDECREF(tmp);
    }

    if (ingredients) {
        self->ingredients = strdup(ingredients);
    }

    return 0;
}

static void PyzzaStuffed_dealloc(PyzzaStuffed* self) {
    //Py_XDECREF(self->order_code);
    Py_TYPE(self)->tp_free((PyObject*)self);
}


static PyObject *PyzzaStuffed_serialize(PyzzaStuffed* self) {
    return Py_BuildValue("O(sss)", Py_TYPE(self), self->order_code, self->ingredients, "pineapple");
}




