#include <Python.h>
#include "structmember.h"
#include "PyzzaMargherita.h"

PyMODINIT_FUNC initpyzzamargherita(void) {
    PyObject* m;

    if (PyType_Ready(&PyzzaMargheritaType) < 0)
        return;

    m = Py_InitModule3("pyzzamargherita", module_methods,
                       "Basic template for pyzzamargherita object");

    if (m == NULL)
        return;

    Py_INCREF(&PyzzaMargheritaType);
    PyModule_AddObject(m, "PyzzaMargherita", (PyObject *)&PyzzaMargheritaType);
}

static PyObject *PyzzaMargherita_new(PyTypeObject *type, PyObject *args, PyObject *kwds) {
	PyzzaMargherita *self;

	self = (PyzzaMargherita *)type->tp_alloc(type, 0);
	if (self != NULL) {
        
		self->order_code = "";
		if (self->order_code == NULL) {
			Py_DECREF(self);
			return NULL;
		}

		self->age = 24;
		self->price = 5;

	}

	return (PyObject *)self;
}

static int PyzzaMargherita_init(PyzzaMargherita *self, PyObject *args, PyObject *kwds) {
    char *order_code = NULL;
    unsigned long age = 0;
	 char *pineapple = NULL;
    PyObject *tmp = NULL;

    static char *kwlist[] = {"age", "order_code", "pineapple", NULL};

    if (!PyArg_ParseTupleAndKeywords(args, kwds, "sk|s", kwlist, &order_code, &age, &pineapple))
        return -1;

    if (order_code) {
        //tmp = self->order_code;
        //Py_INCREF(order_code);
        self->order_code = strdup(order_code);
        //Py_XDECREF(tmp);
    }

    if (age) {
        self->age = age;
    }

    return 0;
}

static void PyzzaMargherita_dealloc(PyzzaMargherita *self) {
	//Py_XDECREF(self->order_code);
	Py_TYPE(self)->tp_free((PyObject*)self);
}

static PyObject *PyzzaMargherita_serialize(PyzzaMargherita* self) {
    return Py_BuildValue("O(sks)", Py_TYPE(self), self->order_code, self->age, "pineapple");
}



