typedef struct {
	PyObject_HEAD
	char *order_code;
	char *ingredients;
	int price;
} PyzzaStuffed;

static void PyzzaStuffed_dealloc(PyzzaStuffed *self);
static PyObject *PyzzaStuffed_new(PyTypeObject *type, PyObject *args, PyObject *kwds);

static int PyzzaStuffed_init(PyzzaStuffed *self, PyObject *args, PyObject *kwds);


static PyMemberDef PyzzaStuffed_members[] = {
    {"order_code", T_STRING, offsetof(PyzzaStuffed, order_code), 0, "order_code"},
    {"ingredients", T_STRING, offsetof(PyzzaStuffed, ingredients), 0, "ingredients"},
    {"price", T_FLOAT, offsetof(PyzzaStuffed, price), 0, "price"},
    {NULL}  
};

static PyObject *PyzzaStuffed_serialize(PyzzaStuffed* self);

static PyMethodDef PyzzaStuffed_methods[] = {
    {"__reduce__", (PyCFunction)PyzzaStuffed_serialize, METH_NOARGS, "Serialize"},
    {NULL}  /* Sentinel */
};

static PyTypeObject PyzzaStuffedType = {
    PyVarObject_HEAD_INIT(NULL, 0)
    "pyzzastuffed.PyzzaStuffed",   /* tp_name */
    sizeof(PyzzaStuffed),             /* tp_basicsize */
    0,                                   /* tp_itemsize */
    (destructor)PyzzaStuffed_dealloc, /* tp_dealloc */
    0,                                   /* tp_print */
    0,                         /* tp_getattr */
    0,                         /* tp_setattr */
    0,                         /* tp_compare */
    0,                         /* tp_repr */
    0,                         /* tp_as_number */
    0,                         /* tp_as_sequence */
    0,                         /* tp_as_mapping */
    0,                         /* tp_hash */
    0,                         /* tp_call */
    0,                         /* tp_str */
    0,                         /* tp_getattro */
    0,                         /* tp_setattro */
    0,                         /* tp_as_buffer */
    Py_TPFLAGS_DEFAULT |
        Py_TPFLAGS_BASETYPE,   /* tp_flags */
    "PyzzaStuffed objects",           /* tp_doc */
    0,                         /* tp_traverse */
    0,                         /* tp_clear */
    0,                         /* tp_richcompare */
    0,                         /* tp_weaklistoffset */
    0,                         /* tp_iter */
    0,                         /* tp_iternext */
    PyzzaStuffed_methods,             /* tp_methods */
    PyzzaStuffed_members,             /* tp_members */
    0,                         /* tp_getset */
    0,                         /* tp_base */
    0,                         /* tp_dict */
    0,                         /* tp_descr_get */
    0,                         /* tp_descr_set */
    0,                         /* tp_dictoffset */
    (initproc)PyzzaStuffed_init,      /* tp_init */
    0,                         /* tp_alloc */
    PyzzaStuffed_new,                 /* tp_new */
};

static PyMethodDef module_methods[] = {
    {NULL}  /* Sentinel */
};

void initpyzzastuffed(void);
