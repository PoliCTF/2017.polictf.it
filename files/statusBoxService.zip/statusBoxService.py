#!/usr/bin/python3.4
import statusBox as cs
import socket
import sys
import multiprocessing


def clientthread(conn):
    s = cs.StatusBox(conn)
    conn.send(b'\n')
    conn.send(b"""StatusBox started! This Box memorizes a statuses
sequence composed by a current status and all the previous ones.
It already contains a small sequence of statuses, but you can show
only the current one.
You can set a new status, modify the current one or delete it: in this way
the box goes back to the previous one in the sequence.
The box can keep track of maximum 200 statuses.
It seems just to work fine, even though we didn't test it a lot...""")
    conn.send(b'\n')
    s.print_current_status()
    conn.send(b'\n\n')

    while(1):
        #conn.send(bytes("Status number: {}\n".format(s.get_pointer()),
        #                "utf-8"))
        conn.send(b'Choose your action:\n')
        conn.send(b'0 - Print the current status;\n')
        conn.send(b'1 - Set a new current status;\n')
        conn.send(
            b'2 - Delete the current status and go back to the previous one;\n'
            )

        conn.send(b'3 - Modify the current status.\n')
        conn.send(b'4 - Exit (statuses will be lost.)\n')

        choice = conn.recv(1024).decode("utf-8")[:-1]
        conn.send(b"\n")
        conn.send(bytes("Your choice was: {}\n".format(choice), "utf-8"))

        if choice == '0':
            s.print_current_status()
        elif choice == '1':
            conn.send(b"Insert the new status:\n")
            status = conn.recv(1024).decode("utf-8")[:-1]
            s.set_new_status(status)
        elif choice == '2':
            s.delete_current_status()
        elif choice == '3':
            conn.send(
                b"Insert the new status, it will modify the current one:\n")
            status = conn.recv(1024).decode("utf-8")[:-1]
            s.modify_current_status(status)
        elif choice == '4':
            conn.send(b'Byebye!\n')
            conn.close()
        else:
            conn.send(b"Wrong choice, input 1,2 or 3.\n")

        conn.send(b"\n")


if len(sys.argv) != 2:
    print("USAGE: statusBoxService PORT")
    sys.exit(0)
else:
    HOST = ''
    PORT = int(sys.argv[1])
    LISTEN = 100
    #LISTEN = int(sys.argv[2])


s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
print('Socket created')

try:
    s.bind((HOST, PORT))
except socket.error as msg:
    print('Bind failed. Error Code : ', str(msg[0]), ' Message ', msg[1])
    sys.exit()

print("Socket bind complete, statusBoxService started on port {}".format(PORT))

#Start listening on socket
s.listen(10)
print('Socket now listening')

while 1:
    conn, addr = s.accept()
    print('Connected with ', addr[0], ':', str(addr[1]))
    multiprocessing.Process(target=clientthread, args=(conn,),).start()

s.close()
