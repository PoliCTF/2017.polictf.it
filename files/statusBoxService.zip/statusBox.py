#!/usr/bin/python3.4
class StatusBox:

    current = 3
    MAX = 200
    statuses = [None for _ in range(256)]
    init_file = 'init_statuses.dat'

    def __init__(self, conn):
        f = open(self.init_file, 'r')
        for l in f.read().split('\n')[:-1]:
            idx = int(l[:l.find(' ')])
            s = l[l.find(' ') + 1:]
            self.statuses[idx] = s

        self.conn = conn

    def get_pointer(self):
        return self.current

    def print_current_status(self):
        self.conn.send(b'CURRENT STATUS:\n')
        if self.statuses[self.current] is None:
            self.conn.send(b"None\n")
        else:
            self.conn.send(bytes(self.statuses[self.current] + '\n', "utf-8"))

    def set_new_status(self, status):
        if status == "":
            self.conn.send(b"Type something, this is empty!\n")
        else:
            if self.current < self.MAX:
                self.current = self.current + 1
                self.statuses[self.current] = status
                self.conn.send(b"Done!\n")
            else:
                self.conn.send(
                    b"You reached the maximum number of statuses!\n")

    def delete_current_status(self):
        if self.current > 0:
            self.statuses[self.current] = None
            self.current = self.current - 1
            self.conn.send(b"Done!\n")
        else:
            self.conn.send(b"You cannot delete more statuses.\n")

    def modify_current_status(self, status):
        if status == "":
            self.conn.send(
                b"You set the current state to empty, so it was deleted.\n")
            self.conn.send(b"Going back to the previous state.\n")
            self.statuses[self.current] = None
            self.current = self.current - 1
        else:
            self.statuses[self.current] = status
            self.conn.send(b"Done!\n")

    #Testing functions:

    #def print_status(self, i):
    #    print(self.statuses[i])

    #def print_all(self):
    #    print(self.statuses)
