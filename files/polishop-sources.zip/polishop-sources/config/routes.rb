Rails.application.routes.draw do
  root 'lister#index'
  post '/lister/search'
  get  '/lister/search'
  get  '/purchaser/buy'
  post '/purchaser/select_card'
  post 'purchaser/pin'
  post 'purchaser/check_pin'
  #get  '*path' => redirect('/404.html')
  #post '*path' => redirect('/404.html')
end
