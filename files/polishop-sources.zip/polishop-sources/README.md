# polictf2017- polishop

* **Title**: Polishop
* **Description**: The Polishop sell everything, from polishirts to the woderfull Poliflag, can you buy it?
* **Category**: Web

## How to Run
Install Ruby. Installation may vary depending on your Linux distribution.

Install Ruby on Rails `gem install rails`

Install bundler `gem install bundler`
Move to the challange folder and run `bundle install` to install all gems required

## Deployment
Move to the challenge folder and run `bundle exec thin start -e production`

## Solution

polishop_exploit.py
