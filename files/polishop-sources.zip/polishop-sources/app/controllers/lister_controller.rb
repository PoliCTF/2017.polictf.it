class ListerController < ApplicationController
  # index show new edit create update destroy
  require 'nokogiri'

  def index
    doc = File.open('db/polishop.xml'){
      |f| Nokogiri::XML(f) }
    items = doc.xpath('//item')
    @items = Array.new
    for n in items do
      temp = Array.new(4)
      temp.insert(0,n.xpath('child::node()[2]/text()'))
      temp.insert(1,n.xpath('child::node()[4]/text()'))
      temp.insert(2,n.xpath('child::node()[6]/text()'))
      temp.insert(3,n.xpath('@id'))
      @items.insert(0,temp)
    end
  end

  def search
    file = params[:file]
    name = params[:name].to_s
    if file.nil?
      file = "polishop.xml"
    end
    if name.nil?
      name = ""
    end
    if file != "creditcards.xml" and file != "polishop.xml"
        @error = "File not Found"
        render 'error'
        return
    end
    doc = File.open('db/'+file){
      |f| Nokogiri::XML(f) }
    begin
        items = doc.xpath('//item[contains(translate(name,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"),"'+name+'")]')
    rescue
        @error = "Invalid search string"
        render 'error'
        return
    end
    if items.to_s == ""
        @items = Array.new
        render 'index'
        return
    end
    nodes = Set.new
    hasOneChild = true
    items.each do |node|
        nodes.add(node.name())
        children = node.xpath('*')
        if children.to_s != ""
            children.each do |child|
                leaves = child.xpath("*")
                if leaves.to_s != ""
                    hasOneChild = false
                end
            end
        else
            hasOneChild = false
        end
    end
    if nodes.size() == 1 and hasOneChild
        @items = Array.new
        for n in items do
          temp = Array.new(4)
          temp.insert(0,n.xpath('*[1]/text()'))
          temp.insert(1,n.xpath('*[2]/text()'))
          temp.insert(2,n.xpath('*[3]/text()'))
          temp.insert(3,n.xpath('@id'))
          @items.insert(0,temp)
        end
        render 'index'
    else
        str_nodes = ""
        nodes.each do |n|
            str_nodes += n + ' '
        end
        if str_nodes == ""
            str_nodes = "nil"
        end
        @error = "Bad query result: expected items but recieved " + str_nodes
        render 'error'
    end
  end
end
