class PurchaserController < ApplicationController
  require 'rexml/document'
  include REXML

  def is_number? string
      puts string
      true if Float(string) rescue false
  end

  def buy
    @any_error = false
    id = params[:item_id]
    @id = id
    if (id =~ /^[0-9]*$/)== 0
        xmlfile = File.new('db/polishop.xml')
        doc = Document.new(xmlfile)
        @item = Array.new(3)
        root = doc.root
        item = XPath.first(root,'inventory/item[@id="'+id+'"]')
        if item.to_s != ""
            @item.insert(0,item.elements["name"].text)
            @item.insert(1,item.elements["price"].text)
            @item.insert(2,item.elements["description"].text)
        else
            @error = "Item not present in the shop"
            render 'lister/error'
        end
    else
        @error = "Invalid Item ID"
        render 'lister/error'
    end
  end

  def select_card
    date = params[:date]
    m = date[:month]
    y = date[:year]
    n = params[:card_number]
    buy()
    @any_error = CheckCard(n,m,y)
    if @any_error == false
      pin()
    else
      render 'lister/error'
    end
  end
  @local_pin = 0
  def CheckCard(cnum,emonth,eyear)
    if cnum =='' || emonth == '' || eyear == ''
      @error = 'Fields cannot be empty'
      return true
    else
        if (cnum =~ /^[0-9]{16}$/) == 0 && (emonth =~ /^[1]?[0-9]$/) == 0 && (eyear =~ /20[0-9]{2}/) == 0
            doc = File.open('db/creditcards.xml'){
                |f| Nokogiri::XML(f) }
            card = doc.xpath('//card[number='+cnum+' and expire_date='+emonth+eyear+']')
            if card.length == 1
              $local_pin = card.xpath('@id')
              return false
            end
        end
        @error = "Wrong combination of card number and date expiration, no card found in creditcards.xml\n"
        return true
    end
  end

  def pin
    cnum = params[:card_number]
    @card_no = cnum
    date = params[:date]
    @exp_date = date[:month]+'/'+date[:year]
    render 'pin', item_id: @id, card_number: cnum
  end

  def check_pin
    puts $local_pin
    puts params[:pin]
    puts params
    if $local_pin.to_s == params[:pin]
      if params[:item_id]=="000005"
        @msg = 'flag{Y0u_need_m0n3y_if_y0u_w4nt_flags}'
        render 'purchase_done'
      else
        @msg = 'Item bought successfully!'
        render 'purchase_done'
      end
    else
      @error = 'Wrong pin'
      render 'lister/error'
    end
  end
end
