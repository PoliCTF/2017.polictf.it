# Title #
Simple File Proxy

# Description #
Our Sysadmin made a simple file proxy to load HTTP resources. We don't know why, but he also decided to allow the user to specify a custom DNS Server...

# Category #
Web

# Deployment #
Serve both the PHP file loadForm.php and flag.txt. In the frontend webserver, make sure that loadForm.php is accessible externally while flag.txt is accessible only from localhost.