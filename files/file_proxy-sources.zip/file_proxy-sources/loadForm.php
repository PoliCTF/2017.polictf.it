<html>
    <body>
        <form action="loadForm.php" method="post">
        File: <input type="text" name="file"><br>
        DNS: <input type="text" name="dns" value="8.8.8.8"><br>
        Port: <input type="text" name="port" value="53"><br>
        <input type="submit">
        </form>
    </body>
</html>

<?php
error_reporting(-1);
ini_set('display_errors', 'On');
require_once 'Net/DNS2.php';

// Check if a specific IP is inside a specific range
function ip_in_range( $ip, $range ) {
        if ( strpos( $range, '/' ) == false ) {
                $range .= '/32';
        }
        // $range is in IP/CIDR format eg 127.0.0.1/24
        list( $range, $netmask ) = explode( '/', $range, 2 );
        $range_decimal = ip2long( $range );
        $ip_decimal = ip2long( $ip );
        $wildcard_decimal = pow( 2, ( 32 - $netmask ) ) - 1;
        $netmask_decimal = ~ $wildcard_decimal;
        return ( ( $ip_decimal & $netmask_decimal ) == ( $range_decimal & $netmask_decimal ) );
}

// Check if an IP is internal
function checkInternal($ip){
        return (ip_in_range($ip, "10.0.0.0/8") ||
        ip_in_range($ip, "172.16.0.0/12") ||
        ip_in_range($ip, "192.168.0.0/16") ||
        ip_in_range($ip, "0.0.0.0/8") ||
        ip_in_range($ip, "127.0.0.0/8"));
}

// Check that all parameters exist
$_POST_lower = array_change_key_case($_POST, CASE_LOWER);
if (!isset($_POST_lower['dns']) || !isset($_POST_lower['port']) || !isset($_POST_lower['file']))
{
    return;
}

if (empty($_POST_lower['dns']) || empty($_POST_lower['port']) || empty($_POST_lower['file']))
{
    return;
}

$dns = $_POST_lower['dns'];
$port = $_POST_lower['port'];
$file = $_POST_lower['file'];

//echo "<p>I am using the following DNS: $dns:$port</p><br>";

$r = new Net_DNS2_Resolver(array(

        'nameservers'   => array($dns),
        'dns_port'      => $port,
));

function getHostIP($file, $r){
    $parsed_url = parse_url($file);
    $host = $parsed_url['host'];
    if(filter_var($host, FILTER_VALIDATE_IP) !== false) {
        // echo $host." is an IP<BR>";
        return $host;
    } else {
        // echo $host." is NOT an IP<BR>";
        $DNSResult = $r->query($host, 'A');
        return ($DNSResult->answer)[0]->address;
    }
}

try
{

    $address = getHostIP($file, $r);

    if (checkInternal($address)){
        echo "Internal IP, shutting down...";
        return;
    }

    // The resource appear to be external, I can load it

    $parsed_url = parse_url($file);
    $address = getHostIP($file, $r);
    $filePath = $parsed_url['scheme']."://".$address.$parsed_url['path'];
    //echo "Accessing resource at $filePath";

    $handle = fopen($filePath, "rb");
    if (FALSE === $handle) {
        exit("Failed to open stream to URL");
    }

    $contents = '';
    $contents .= fread($handle, 8192);
    fclose($handle);
    echo "Here is the requested resource!<br>";
    echo htmlspecialchars($contents);


} catch(Net_DNS2_Exception $e)
{
    // Should replace with a generic error
    echo "Unable to contact the DNS server";
}
?>